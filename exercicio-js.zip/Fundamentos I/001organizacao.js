console.log('bom dia')//sentença de codigo

{
    {
        console.log('ola')///// Bloco de
        console.log('mundo')/// Código
    }
}