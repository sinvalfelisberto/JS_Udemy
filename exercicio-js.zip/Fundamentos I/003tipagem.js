let qualquer = 'legal'
console.log(qualquer)
console.log(typeof qualquer)

qualquer = 3.123
console.log(qualquer)
console.log(typeof qualquer)