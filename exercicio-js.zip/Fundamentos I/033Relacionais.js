console.log( '01)', '1' == 1)
console.log( '02)', '1' === 1)
console.log( '03)', '3' != 3)