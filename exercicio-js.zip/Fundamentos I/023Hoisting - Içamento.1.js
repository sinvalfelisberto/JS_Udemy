console.log(`a = ${a}`)
var a = 2
console.log(`a = ${a}`)

function teste() {
    console.log(`a = ${a}`)
    var a = 2
    console.log(`a = ${a}`)
}
teste()

//usando let

console.log(`b = ${b}`)
var b = 2
console.log(`b = ${b}`)