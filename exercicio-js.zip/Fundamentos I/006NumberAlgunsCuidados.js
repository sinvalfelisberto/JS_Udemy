console.log(7 / 0) //infinity
console.log('10' / 5)
console.log('show' * 2)
console.log(0.1 + 0.7)
console.log('1'+1)
console.log('1' - 1)
console.log('1' / 1)
