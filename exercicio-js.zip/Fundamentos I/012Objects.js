//obj é uma coleção de chaves e valores
const prod1 = {}
prod1.nome = 'Celular Ultra Mega'
prod1.preco = 799.99
prod1['Desconto Legal'] = 0.40 //evitar de atributos com espaço

console.log(prod1)

const prod2 = {
    nome: 'Camisa Polo',
    preco: 79.99
}

console.log(prod2)