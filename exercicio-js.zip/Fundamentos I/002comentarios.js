console.log('teste') //comentario de uma linha
/*
* comentario de 
* mais de uma linha
*/