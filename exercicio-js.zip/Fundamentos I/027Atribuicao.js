const a = 7
let b = 3

b += a
console.log(`b += 2 == ${b}`)


b -= 4
console.log(`b -= 2 == ${b}`)


b *= 2
console.log(`b *= 2 == ${b}`)


b /= 2
console.log(`b /= 2 == ${b}`)


b %= 2
console.log(`b %= 2 == ${b}`)