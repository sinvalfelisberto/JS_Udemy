var a = 3
let b = 4

var a = 5
b = 6 //let previne que não seja redeclarada a variavel

console.log(a, b)
const c = 3.14
c = 15 //não é possível declarar novo valor à variavel