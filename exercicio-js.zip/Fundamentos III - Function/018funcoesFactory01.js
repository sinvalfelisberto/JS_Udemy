// Factory simples
function criarPessoa() {
    return {
        nome: 'Ana',
        sobrenome: 'Silva', 
        idade: 20
    }
}

console.log(criarPessoa())